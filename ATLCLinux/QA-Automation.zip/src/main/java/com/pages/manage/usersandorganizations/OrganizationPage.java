package com.pages.manage.usersandorganizations;

public class OrganizationPage {
}
