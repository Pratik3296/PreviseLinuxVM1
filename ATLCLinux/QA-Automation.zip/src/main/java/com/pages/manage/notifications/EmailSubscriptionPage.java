package com.pages.manage.notifications;

public class EmailSubscriptionPage {
}
