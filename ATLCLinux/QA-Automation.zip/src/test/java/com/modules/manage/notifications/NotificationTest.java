package com.modules.manage.notifications;

import com.genericUtils.BaseTest;

public class NotificationTest extends BaseTest {
}
