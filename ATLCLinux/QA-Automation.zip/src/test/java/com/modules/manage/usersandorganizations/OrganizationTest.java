package com.modules.manage.usersandorganizations;

import com.genericUtils.BaseTest;

public class OrganizationTest extends BaseTest {
}
