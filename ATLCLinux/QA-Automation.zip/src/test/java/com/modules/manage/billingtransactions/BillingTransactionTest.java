package com.modules.manage.billingtransactions;

import com.genericUtils.BaseTest;

public class BillingTransactionTest extends BaseTest {
}
