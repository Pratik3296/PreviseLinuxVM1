package com.modules.manage.usersandorganizations;

import com.genericUtils.BaseTest;

public class UserTest extends BaseTest {
}
