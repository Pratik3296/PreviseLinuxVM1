package com.modules.reports;

import com.genericUtils.BaseTest;

public class ReportsTest extends BaseTest {
}
